# JSON Consistency Repair — Comparative Benchmark V1

Date: 2026-08-21  
Engine: json-consistency-repair 0.41.0 working tree  
Purpose: measure limits and comparative behavior, not produce a superiority narrative.

## 1. What this benchmark can and cannot compare

The environment contains Python stdlib `json`, `orjson 3.11.9`, `ujson 5.12.1`, `json5 0.14.0`, `PyYAML 6.0.3`, and `jsonschema 4.26.0`. These provide strict parsing, permissive parsing, or validation. None is a direct semantic JSON consistency-repair engine. Therefore the benchmark separates: (a) shared-domain tests where the tools can be compared directly, and (b) capability gaps where a parser is marked "no repair API" rather than scored as a failed repairer.

A dedicated third-party semantic JSON-repair comparator remains an external gate because no such package is installed locally and no web installation was used.

## 2. The earlier 30–40% failures were not hard repair limits

This was retested explicitly. The high-corruption cases that sometimes failed without independent authority were underbounded: the observed records no longer uniquely identified which coherent regime was the intended one. Once a solid independent bound was supplied, the same engine repaired almost-total corruption.

| Bound test | Corruption | Exact repairs | False mutations |
|---|---:|---:|---:|
| Functional authoritative implications | 39/40 targets wrong (97.5%), 3 seeds | **117/117** | **0** |
| Arithmetic authoritative balance | 39/40 totals wrong (97.5%), 3 seeds | **117/117** | **0** |
| Missing functional values, learned carrier | 20/40 missing (50%), 3 seeds | **60/60** | **0** |

So the previous drop at 30–40% is an **identifiability/boundary limit of the evidence available in that corpus**, not a demonstrated computational ceiling of the repair engine. If two regimes remain coherent and no authoritative bound distinguishes them, abstention is the correct terminal.

## 3. Shared-domain malformed JSON recovery

The corpus contains 200 malformed but uniquely recoverable JSON documents spanning ten corruption families: trailing comma, missing comma, missing colon, truncated object, truncated nested container, missing closing quote, extra brace, two simultaneous structural errors, array trailing comma, and array missing comma. Expected semantics were fixed before execution.

| Tool | Exact recoveries | Wrong accepted semantics | Rejected |
|---|---:|---:|---:|
| **JCR grammar repair** | **200/200** | **0** | 0 |
| JSON5 | 40/200 | 0 | 160 |
| PyYAML safe | 40/200 | **40/200** | 120 |
| stdlib json | 0/200 | 0 | 200 |
| orjson | 0/200 | 0 | 200 |
| ujson | 0/200 | 0 | 200 |

On this corpus, JCR's syntax-repair layer has a real recovery advantage rather than merely permissive acceptance.

## 4. Coverage where JCR deliberately loses

A separate 60-case corpus used syntax that is not strict JSON: single-quoted strings, unquoted keys, and JavaScript-style comments.

| Tool | Exact accepts | Wrong accepts | Rejects |
|---|---:|---:|---:|
| JSON5 | **60/60** | 0 | 0 |
| PyYAML safe | 20/60 | **40/60** | 0 |
| **JCR grammar repair** | 0/60 | 0 | **60/60** |
| stdlib/orjson/ujson | 0/60 | 0 | 60/60 |

This is a genuine coverage limitation, by design: JCR 0.41 does not silently reinterpret JSON as JSON5/JavaScript. JSON5 is strictly broader on these language features.

## 5. Duplicate-key ambiguity and clean-data safety

For 100 documents containing duplicate keys such as `{"a":1,"a":2}`, stdlib json, orjson, ujson, json5 and PyYAML all accepted 100/100 under their own duplicate-key behavior. JCR rejected 100/100 rather than silently choosing a value. Acceptance here is not counted as a repair because the intended member is not identified by the carrier.

On 20 randomly generated structured clean corpora, the full JCR engine made **0 mutations**.

## 6. Learned semantic repair frontier without external bounds

PASS041's same-engine corruption campaign was retained because it directly measures the learned-evidence frontier. Every reported trial had zero false mutations.

| Wrong targets | Functional exact recall | Arithmetic exact recall |
|---:|---:|---:|
| 3/40 (7.5%) | **100%** | **100%** |
| 8/40 (20%) | **100%** | **100%** |
| 12/40 (30%) | **100%** | 66.7% |
| 16/40 (40%) | 66.7% | 33.3% |

This table must not be read as a hard corruption ceiling. Section 2 demonstrates that, when solid bounds replace ambiguous learned evidence, 97.5% corruption is repaired exactly in the tested families.

Conventional parsers are not assigned 0% semantic-repair scores here because they do not expose a comparable cross-record repair API. `jsonschema` validates declared schemas but did not provide a materializing cross-field repair path in the tested environment.

## 7. Valid JSON correctness

On 500 generated valid JSON documents, stdlib json, orjson, ujson, JSON5 and PyYAML all reproduced the expected semantics 500/500. JCR full was checked on 30 clean documents and preserved 30/30 with 0 committed edits. There is no correctness advantage to claim on ordinary valid JSON.

## 8. Performance reality

On a 7,711-byte valid document:

| Tool/path | Throughput |
|---|---:|
| orjson | **271.3 MB/s** |
| ujson | **220.0 MB/s** |
| stdlib json | **134.4 MB/s** |
| JCR grammar exact path | **8.48 MB/s** |
| PyYAML safe | 0.347 MB/s |
| JSON5 | 0.078 MB/s |
| **JCR full consistency engine** | **0.0112 MB/s** (~0.689 s/document) |

JCR is therefore **not a raw parsing-speed competitor**. Its grammar exact path is already much faster than the full consistency engine, but still far behind optimized JSON parsers. The full engine pays for relation discovery, candidate generation, falsification, minimal transfer, replay and certification.

## 9. Exact comparative verdict

What is established by this local benchmark:

1. **Malformed deterministic JSON recovery:** JCR is materially stronger than the installed strict/permissive parser set on the tested ten corruption families: 200/200 exact, no wrong materializations.
2. **Semantic consistency repair:** JCR has capabilities the installed parser/validator tools simply do not expose: learned cross-record reconstruction, wrong-value correction, authoritative cross-field repair, replay and abstention.
3. **Bounds matter:** failures under heavy corruption disappear when the missing authoritative constraint is supplied; 97.5% corruption was repaired exactly in the tested functional and arithmetic families.
4. **Ambiguity safety:** JCR preserves ambiguity rather than silently resolving duplicate-key conflicts.
5. **Language coverage:** JSON5 wins decisively on non-strict JSON5 syntax that JCR intentionally rejects.
6. **Speed:** orjson/ujson/stdlib win decisively on valid JSON parsing throughput.

What is **not** established:

- superiority over every JSON repair package or commercial data-quality system;
- comparison against dedicated tools such as third-party JSON-repair libraries that are not installed in this runtime;
- universal corruption tolerance;
- that every abstention can be closed without additional evidence.

The strongest defensible statement is therefore: **the JSON repairer is already in a different functional class from ordinary JSON parsers on deterministic reconstruction and semantic consistency repair, but it is dramatically slower on ordinary valid parsing and still lacks a direct benchmark against dedicated third-party JSON-repair systems.**

Raw results SHA-256: `9bcc5525d824dbddd04609883cec4294b272b04f245428f9fb03e3f445ca8dac`
