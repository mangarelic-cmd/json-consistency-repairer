# PASS036 REPORT — JSON Consistency Repair v0.36.0

Status: **PASS036 CLOSED**

PASS036 implements repair controllability and reachability under the actual mutation surface. It is the fourth completed substantive pass of the fifth series identified by the post-PASS032 global SC/AUX/CT audit. Fifth-series progress after this pass: **4/8 completed, 4 remaining**.

## What changed

- Mathematical identifiability is separated from legal/operational reachability. A known repair that cannot be actuated is preserved as `IDENTIFIABLE_BUT_UNREACHABLE`; it is not collapsed to `UNKNOWN`.
- Candidate writes pass through a pre-optimization controllability firewall. Rules can mark JSON-pointer scopes immutable, allow or deny operations, require explicit permission coverage, and scope policy by document.
- Atomic multi-path plans are checked at every internal write rather than receiving permission only from their outer wrapper.
- Selected repair sets compile into explicit control plans. `must_precede` dependencies are topologically ordered; a precedence cycle is an explicit unreachable state.
- Global and policy-level edit/cost budgets are intersected conservatively. Budget consumption is cumulative across committed cycles.
- Repaired-terminal cold replay receives the already-consumed budget state, preventing replay from spending the same budget twice. Proof-graph replay from the sovereign original input retains the original budget state.
- Externally attributed controllability policy is upstream-gated by PASS033 semantic-claim provenance; an unverifiable external lock cannot block or authorize a mutation.
- Single JSON, bundle and streaming surfaces expose the control evidence. PASS028 proof graph and PASS032 rectification packet commit it; the independent certifier re-verifies all emitted control certificates.

## Public contracts

- `json-consistency-repair.repair-controllability.v1`
- `json-consistency-repair.controllability-firewall.v1`
- `json-consistency-repair.repair-controllability-summary.v1`

Public Draft 2020-12 schemas validated in this release: **59/59**.

## Validation

Working-tree regression after final PASS036 code/version/docs changes:

- core→PASS010: 104/104
- PASS011→PASS020: 97/97
- PASS021→PASS028: 90/90
- PASS029→PASS036: 107/107
- total: **398/398 tests PASS**

Dedicated PASS036 stress: **600/600**:

- explicit permission allow: 100/100
- immutable-path block: 100/100
- cumulative budget gate: 100/100
- precedence compilation: 100/100
- precedence-cycle gate: 100/100
- semantic-policy poisoning gate: 100/100

PASS036 benchmark: **600/600**, **0 false mutations**.

Certified stress ledger:

- inherited through PASS035: 19,225
- fresh PASS036: 600
- cumulative: **19,825/19,825**

The inherited 19,225 is predecessor-certified evidence; only PASS036 600/600 is claimed as the fresh dedicated campaign here. With the current 398-test suite, aggregate test+ledger count is **20,223**.

## Distribution verification

- release version: 0.36.0
- runtime external dependencies: **0**
- reproducible wheel/source build check: PASS
- fresh-wheel `pip check`: PASS
- fresh-wheel package version: 0.36.0
- fresh-wheel legal repair witness: `/x: 1 -> 2`, control plan `CONTROLLABLE`
- fresh-wheel immutable witness: `IDENTIFIABLE_BUT_UNREACHABLE`, no mutation, final certification `CERTIFIED`
- fresh-wheel exhausted-budget witness: `IDENTIFIABLE_BUT_UNREACHABLE`, no selected action
- fresh-wheel proof replay: `PROOF_GRAPH_REPLAY_EXACT`
- fresh-wheel fifth-series progress: 4 completed / 4 remaining / `IN_PROGRESS`

The final source archive was extracted independently and rerun in the same four regression segments: **398/398 tests PASS**. Extracted-source dedicated PASS036 stress is **600/600** and its regenerated PASS036 benchmark is byte-identical to the release benchmark.

## Hashes

- package-code SHA-256: `f34e701a6dedae874bf91da94a662fcdf8f1a2696a3f312f396ea4177856b5aa`
- wheel SHA-256: `f410d1e971abe5aa27e0645002df135db58947add56aae176f166b3d6e30a231`
- source SHA-256: `ee37bf30c914fb7091c0755bceab820150bf39921595328b58050bc7ce0fab78`
- benchmark SHA-256: `8f5ad692fe12b2e87cef04310aa0b3c5d6483448bf5b15524f5ab405ad6ae519`
- `controllability.py` SHA-256: `9889d4ce4c7257414bae0d10b89297619275297f03718bee0dcfc65e0b963744`
- independent certifier SHA-256: `444681f393d421f9f0afb41601b8a56e0c16af7bee37e226e066fa17ec870497`
- release provenance SHA-256: `0e7dae435bdb152425ed5b591b40b845dcf77d03170cd72722a4f36d97a4888b`

Exact predecessor cumulative archive:

- `json-consistency-repair-v0.35.0-PASS035-CUMULATIVE.zip`
- SHA-256: `3511838b66c0728e7a52c072553187e8c91f8cc288b80a81d3cf6b06d179eb54`

## Fifth-series status

Completed: PASS033, PASS034, PASS035, PASS036.

Remaining substantive passes: **4** — PASS037 active falsification/negative controls; PASS038 persistent OPEN obligations/incremental recomputation; PASS039 horizon naturality/distributed consistency; PASS040 residual-information/blind-carrier reconstruction and final fifth-series reconciliation.
