# PASS034 REPORT — typed expression IR + finite repair-path algebra

Version: **0.34.0**  
Status: **PASS034 CLOSED**  
Fifth-series progress: **2/8 completed; 6 substantive passes remaining**

## Objective

PASS034 implements the second transfer identified by the post-PASS032 global SC/AUX/CT/primes audit: make configured formulae and repair actions themselves typed, inspectable objects. The pass has two coupled surfaces:

1. a safe exact `TYPED_EXPRESSION_IR` for authoritative formula constraints; and
2. a finite `REPAIR_PATH_ALGEBRA` that proves termination on a frozen one-shot action frontier, analyzes critical pairs, and blocks unordered patch sets whose overlaps are not shown to rejoin.

This is deliberately narrower than a theorem of global confluence. The certificate is scoped to the candidate identities that actually exist on the frozen repair snapshot.

## Typed expression IR

The DSL accepts `expr name: lhs = rhs`. Expressions compile without Python `eval` or arbitrary calls. Supported operators are exact `+`, `-`, `*`, `/`, integer powers, square root, modulo, absolute value, min/max, floor/ceil, finite sum and finite product. Names/dotted names denote record fields.

Arithmetic is exact over rational numbers. A repair candidate is emitted only when the configured equation uniquely identifies a target and the result can be represented exactly by the JSON carrier. Integer and finite base-10 rational projections are allowed; non-terminating rational JSON numbers remain `OPEN_NONFINITE_JSON_NUMBER`. Even powers retain sign symmetry; modulo, floor/ceil and other non-unique inverse families do not invent a branch.

A bare LHS field is treated as the declared formula output (`BARE_LHS_OUTPUT`). Symmetric equations remain symmetric unless `solve_for` explicitly breaks that orientation.

## Repair-path algebra

Each candidate becomes a `typed-repair-action.v1` record with canonical identity, operation, path, read set, write set, precondition digest, postvalue digest and semantic dependency paths when supplied by an analyzer.

For each frozen finite frontier PASS034 computes:

- a decreasing rank `remaining_unused_action_identities`;
- one-shot action reuse prohibition;
- exact disjoint read/write commutation proofs;
- bounded normal-form exploration for overlapping action pairs;
- `JOINABLE_CRITICAL_PAIR` when branches rejoin;
- `CRITICAL_PAIR_OPEN` when they do not;
- an explicit overflow state when a bounded frontier cannot be certified.

The minimal-transfer solver rejects an unordered multi-action subset if that subset contains an unresolved critical pair. Ordered PASS026 parallel routes keep their own RETURN_PROOF semantics and are not incorrectly forced to commute.

The algebra is serialized into single-object reports, computed document-wise for bundles, and inherited through the authoritative per-record bridge for streaming. The PASS032 rectification packet commits both PASS034 surfaces. The independent certifier verifies serialized action/pair/algebra hashes and invariants.

## Regression discovered during implementation

A first symmetric interpretation of `total = subtotal + tax` correctly exposed three mathematically possible inverse repairs, which caused PASS026 to abstain. For formula syntax this was too weak: the normal user intent is an oriented output formula. PASS034 therefore distinguishes a bare LHS output from a genuinely symmetric equation. This preserves conservative behavior while making formulas operational without arbitrary tie breaking.

A second carrier issue was closed explicitly: exact rational arithmetic cannot justify writing `0.333333...` for `1/3`. PASS034 tests and stress now require non-finite JSON decimals to remain OPEN while exact finite values such as `1/8 -> 0.125` may materialize.

## Validation

Working-tree regression was executed in five bounded segments:

- 77/77
- 70/70
- 92/92
- 63/63
- 69/69

Total: **371/371 tests PASS**.

Dedicated PASS034 tests: **16/16**.

Dedicated PASS034 stress: **600/600**, split evenly across:

- exact expression projection;
- non-unique inverse abstention;
- non-finite JSON rational abstention;
- disjoint commutation proof;
- critical-pair joinability;
- open-pair + algebra-tamper firewall.

PASS034 benchmark: **600/600**, **0 false mutations**.

Certified stress ledger: predecessor PASS033 **18,025** + fresh PASS034 **600** = **18,625/18,625**. Historical entries are inherited certification, not claimed as a fresh rerun under PASS034 semantics.

Tests + certified stress ledger: **18,996 checks**.

All **53 public Draft 2020-12 schemas** validate.

## Distribution validation

- wheel reproducibility: PASS, byte-identical independent builds;
- source reproducibility: PASS, byte-identical independent builds;
- fresh wheel `pip check`: PASS;
- external runtime dependencies: 0;
- fresh-wheel expression witness: one exact repair, `CERTIFIED`;
- fourth-series closure: `CLOSED`;
- fifth-series progress: `IN_PROGRESS`, completed=2, remaining=6;
- proof-graph replay: `PROOF_GRAPH_REPLAY_EXACT`;
- independent algebra certifier check: PASS;
- extracted source regression: **371/371**;
- extracted source PASS034 stress: **600/600**;
- extracted-source benchmark: byte-identical with release benchmark.

## Artifact hashes before cumulative packaging

- package code: `ddce5ddf0c8954e6e936759f00f0122754f6dd027f677143413cd9908bf6f71d`
- wheel: `08657188aa6a1e5d727d4c5315b845f4192357426c0f9694893b2ed7476e33eb`
- source: `4d3761c5b3706b52e8039285256e0598f2a84567b0ed63554d4c263fe7867463`
- benchmark: `3915057d0e0190e2ce83fd313e330ff5d04ec2c0275331cfb4b8743143539c05`
- certifier code: `edec8c986e449fe69638e012d829f74d48b4cc2bfe4d12b94a2db8b08e849295`
- expression IR code: `9207257da16488e3285759e9ad159bffa4ae7c06e6f2525eaec96ee966ec2305`
- repair algebra code: `8d25d365303013d3b076e04a17ccba5a079e3893d2a4cf7ce207eadbcb841163`
- exact PASS033 predecessor cumulative: `9b5c81ab12f8351d760eba5e0a53bbc338754cc5237d8a4f3d6874c435a5791b`

## Closure statement

PASS034 is closed for its intended scope. It does **not** claim global confluence over unknown future rewrite rules. It certifies the finite repair frontier that exists at decision time and abstains when that frontier cannot be proved terminating/joinable under the declared bound.

Next substantive pass: **PASS035 — symmetry obstruction + semantic quotient/canonicality**.
