# PASS038 REPORT — JSON Consistency Repair v0.38.0

Status: **PASS038 CLOSED**

PASS038 implements persistent OPEN obligations, targeted wake-up and certified incremental recomputation. It is the sixth completed substantive pass of the fifth series identified by the post-PASS032 global SC/AUX/CT audit. Fifth-series progress after this pass: **6/8 completed, 2 remaining**.

## What changed

- Unresolved terminals are materialized as a hash-bound `json-consistency-repair.open-obligation-registry.v1` instead of disappearing at process exit.
- OPEN semantics are explicit: `OPEN != ABSENT != IMPOSSIBLE`; unmatched obligations remain persisted.
- Each obligation carries typed dependency and wake tokens such as `path:/x`, `source:*`, `permission:*`, `schema:*`, `boundary:*`, `counterexample:*` and `rewrite:*`.
- Registry persistence is atomic and tamper-detected.
- New evidence/rules wake only obligations whose explicit wake/dependency tokens intersect the supplied change tokens.
- JSON structural diffs compile deterministic path tokens for targeted wake-up.
- PASS028 proof-graph nodes receive a conservative proof dependency index; opaque nodes fall back to `global:*` instead of claiming unsafe locality.
- The incremental transition is compared against a fresh full OPEN-obligation registry. Any unexplained disappearance/change returns `FULL_RECOMPUTE_REQUIRED`.
- Optional prior proof graphs can reuse retained nodes only when exact payload hashes still match and the existing full proof-graph replay independently agrees.
- Incremental optimization never weakens publication gates: cold replay and full proof-graph replay remain authoritative.
- Single JSON, bundle and streaming expose the PASS038 registry/recompute surfaces and are independently certified.

## Public contracts

- `json-consistency-repair.open-obligation-registry.v1`
- `json-consistency-repair.open-obligation-wake-plan.v1`
- `json-consistency-repair.proof-dependency-index.v1`
- `json-consistency-repair.incremental-recompute.v1`
- `json-consistency-repair.incremental-equivalence.v1`

Public Draft 2020-12 schemas validated in this release: **66/66**.

## Validation

Working-tree regression after final PASS038 code/version/docs changes was executed in four deterministic segments:

- core→PASS010: 104/104
- PASS011→PASS020: 97/97
- PASS021→PASS028: 90/90
- PASS029→PASS038: 132/132
- total: **423/423 tests PASS**

Dedicated PASS038 stress: **600/600**:

- persistent registry: 100/100
- targeted wake: 100/100
- incremental equivalence: 100/100
- conservative fallback: 100/100
- proof dependency index: 100/100
- JSON diff wake tokens: 100/100

PASS038 benchmark: **600/600**, **0 false mutations**.

Certified stress ledger:

- inherited through PASS037: 20,425
- fresh PASS038: 600
- cumulative: **21,025/21,025**

The inherited 20,425 is predecessor-certified evidence; only PASS038 600/600 is claimed as the fresh dedicated campaign here. With the current 423-test suite, aggregate test+ledger count is **21,448**.

## Distribution verification

- release version: 0.38.0
- runtime external dependencies: **0**
- reproducible wheel/source build check: PASS
- fresh-wheel `pip check`: PASS
- fresh-wheel package version: 0.38.0
- persistent OPEN witness: schema-identifiable `/x` remains unchanged under explicit-permission policy and is persisted as OPEN control/source obligations
- proof dependency fallback for opaque nodes: conservative `global:*`
- incremental registry equivalence check: PASS
- source archive extracted independently: **423/423 tests PASS**
- extracted-source PASS038 stress: **600/600**
- extracted-source regenerated benchmark: byte-identical

## Hashes

- package-code SHA-256: `bb311b38830b098b7c9793cffbde6289c2aae698c5ad9e32229b1f9083d6081b`
- wheel SHA-256: `cd9626f48ecd1042f6c222e9cc95bf5dce3830137457bb8b65891828e4ca04c3`
- source SHA-256: `8edfaec6af05aaa37e61044604b64a3aa1fa5a05187da5ca80fd3b1762f8d643`
- benchmark SHA-256: `c3db8defa79fcc2a60d7a7b7ccdc7b51cd4a036e5bd22dbf954c1908209bfa43`
- `persistent_open.py` SHA-256: `6728859a981f49ba9b2f43cd35fad29fc27003a3271159791b2fd0640042e1ba`
- independent certifier SHA-256: `98d171114b4f81f1defe6acca107340fe0ebf1238eae2ac8c7fe46185a661e42`
- release provenance SHA-256: `91fdfe5a021ce32394b1add387866421df9c13fcb724563404c1b1ca5c018d95`

Exact predecessor cumulative archive:

- `json-consistency-repair-v0.37.0-PASS037-CUMULATIVE.zip`
- SHA-256: `de739dcf2c51a10edd12d9e9a23d6b79bb797a80126e9fc3f78380863db59784`

## Fifth-series status

Completed: PASS033, PASS034, PASS035, PASS036, PASS037, PASS038.

Remaining substantive passes: **2** — PASS039 horizon naturality/distributed consistency; PASS040 residual-information lower bounds/blind-carrier reconstruction and final fifth-series reconciliation/closure.

## Cumulative packaging

A single deterministic PASS038 cumulative archive would be 251,135,086 bytes, which exceeds the project 250,000,000-byte packaging threshold. PASS038 is therefore released as two deterministic cumulative volumes instead of publishing the oversized single archive as the primary handoff:

- VOL1: exact PASS037 cumulative predecessor + volume note.
- VOL2: complete PASS038 active tree/delta, excluding the already-carried predecessor blob + volume note.

Reconstruction order is VOL1 predecessor first, then overlay VOL2 at the same project root. This avoids duplicating or modifying the exact predecessor while keeping each downloadable ZIP below the requested threshold.
