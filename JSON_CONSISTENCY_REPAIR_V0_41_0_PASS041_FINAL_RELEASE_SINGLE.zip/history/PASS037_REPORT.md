# PASS037 REPORT — JSON Consistency Repair v0.37.0

Status: **PASS037 CLOSED**

PASS037 implements active relation falsification, deterministic negative controls, bounded ablations and counterexample gating. It is the fifth completed substantive pass of the fifth series identified by the post-PASS032 global SC/AUX/CT audit. Fifth-series progress after this pass: **5/8 completed, 3 remaining**.

## What changed

- Inferred relations are attacked before federation and optimization instead of being accepted merely because no counterexample was already present.
- Functional/scoped-functional relations receive deterministic split-fold mapping checks, zero-input baseline ablation and bounded target-rotation negative controls.
- A relation whose determinant adds no information is classified `NEGATIVE_CONTROL_INVARIANT`; relation-backed repairs that depend only on blocking relations are gated before mutation.
- Independent heldout lifecycle `GLOBAL_REFUTED` evidence becomes `ACTIVE_REFUTED` and blocks dependent candidates.
- Existing independently confirmed/portable relations are represented as adversarially survived evidence rather than silently promoted.
- Exact arithmetic and temporal relation families receive bounded negative controls; unsupported relation families remain explicitly `OBSERVED_ONLY` rather than receiving fabricated robustness claims.
- Authoritative relations are separated as `AUTHORITATIVE_CONTRACT`: empirical falsification does not pretend to invalidate an explicit authoritative contract, while PASS033 still protects the semantic provenance of that contract.
- Synthetic controls are tests only. They never enter the observation corpus, support counts, heldout evidence or authority graph.
- Every falsification result is SHA-bound and independently reverified by the final certifier.
- Single JSON, bundle and streaming expose falsification evidence. Streaming attacks its native discovered relation registry before candidate application; the record bridge retains the same firewall.
- PASS028 proof graph and PASS032 rectification packet now commit the relation-falsification surface.

## Public contracts

- `json-consistency-repair.relation-falsification.v1`
- `json-consistency-repair.relation-falsification-summary.v1`

Public Draft 2020-12 schemas validated in this release: **61/61**.

## Validation

Working-tree regression after final PASS037 code/version/docs changes was executed in four deterministic segments:

- core→PASS010: 104/104
- PASS011→PASS020: 97/97
- PASS021→PASS028: 90/90
- PASS029→PASS037: 118/118
- total: **409/409 tests PASS**

Dedicated PASS037 stress: **600/600**:

- functional adversarial survival: 100/100
- negative-control invariance gate: 100/100
- split-fold refutation: 100/100
- independent counterexample gate: 100/100
- authoritative-contract separation: 100/100
- certificate-tamper rejection: 100/100

PASS037 benchmark: **600/600**, **0 false mutations**.

Certified stress ledger:

- inherited through PASS036: 19,825
- fresh PASS037: 600
- cumulative: **20,425/20,425**

The inherited 19,825 is predecessor-certified evidence; only PASS037 600/600 is claimed as the fresh dedicated campaign here. With the current 409-test suite, aggregate test+ledger count is **20,834**.

## Distribution verification

- release version: 0.37.0
- runtime external dependencies: **0**
- reproducible wheel/source build check: PASS
- fresh-wheel `pip check`: PASS
- fresh-wheel package version: 0.37.0
- fresh-wheel relation witness: missing `B` target reconstructed to `beta` only after the nontrivial functional dependency survived the active falsifier
- fresh-wheel final certification: `CERTIFIED`
- fresh-wheel relation-falsification certifier check: PASS
- fresh-wheel proof replay: `PROOF_GRAPH_REPLAY_EXACT`
- fresh-wheel fifth-series progress: 5 completed / 3 remaining / `IN_PROGRESS`

The final source archive was extracted independently and rerun in the same four regression segments: **409/409 tests PASS**. Extracted-source dedicated PASS037 stress is **600/600** and its regenerated PASS037 benchmark is byte-identical to the release benchmark.

## Hashes

- package-code SHA-256: `07c947e7e417e49ae3a502245317749500a4dc0905e6c84f152dc35534f66c5f`
- wheel SHA-256: `13d8f40187557a7aa9b362a9fc7c8bed5ef270809dcebc09ae2818d9f99f0402`
- source SHA-256: `af8a2e20c9b8f3fb26cfe8bb0dab59f8bf7d53baab0be54d9a9f262dbefcf7c5`
- benchmark SHA-256: `a8bf34ea07b35992824a4d6ffd80772efbe488a50fb71c1268f39d60ebd79c61`
- `relation_falsifier.py` SHA-256: `263d427546403534f2e2da955b95be84b6f88313fc8725f0d440863ed66014e7`
- independent certifier SHA-256: `7e86324a6721d8d1f0f6d95ee7e6723bc8cf8a33d5d83682763083b2e4c5e0a8`
- release provenance SHA-256: `0027a13da166cf7c1ceff7f8c0cfad38648fe1e54308345e953ab52cdaff917a`

Exact predecessor cumulative archive:

- `json-consistency-repair-v0.36.0-PASS036-CUMULATIVE.zip`
- SHA-256: `0b8dbe3b9893f132d53cf515377c1006326150f7f065ee247f8345d13aa85a52`

## Fifth-series status

Completed: PASS033, PASS034, PASS035, PASS036, PASS037.

Remaining substantive passes: **3** — PASS038 persistent OPEN obligations/targeted incremental recomputation; PASS039 horizon naturality/distributed consistency; PASS040 residual-information/blind-carrier reconstruction and final fifth-series reconciliation.
