# PASS031 REPORT — Robust uncertainty / clock / regime / hysteresis envelopes

Version: **0.31.0**  
Date: 2026-08-20  
Status: **PASS031_CLOSED**

## Scope

PASS031 adds a robustness firewall **before minimal-transfer optimization**. A correction that is valid only at one nominal point is no longer automatically admissible when an explicit uncertainty, clock, regime, or hysteresis envelope says that nearby states remain causally possible.

The invariant is:

`candidate closure at nominal snapshot`  
`+ declared admissible envelope`  
`-> candidate must survive the envelope or abstain`.

The layer does not import domain-specific physical laws. It ports only the generic SC operators: admissible-set boundaries, explicit clock domains, regime preservation, hysteresis no-flip bands, and proof-carrying gates.

## New public contracts

- `json-consistency-repair.robust-envelope.v1`
- `json-consistency-repair.robust-envelope-firewall.v1`
- `json-consistency-repair.robust-envelope-summary.v1`

Public schema:

- `schemas/robust-envelope-v1.schema.json`

CLI:

```text
json-consistency-repair input.json --robust-envelope robust.json
```

The rule file may be a raw rule array or an object containing `evaluation_time` plus `rules`.

## Uncertainty envelopes

`uncertainty_interval` supports exact admissible intervals from:

- explicit lower/upper paths;
- center + radius;
- center + sigma × `k`;
- literal radius/sigma values.

A point correction whose proposed value lies **inside the currently admissible interval** is not treated as uniquely identifiable and is removed from optimization:

`CANDIDATE_WITHIN_ADMISSIBLE_UNCERTAINTY -> abstain`.

A candidate separated from the entire declared current interval may continue through the ordinary minimal-transfer, Q-descent, replay, inverse and certifier gates.

Concrete witness:

```json
{"x":10,"u":2}
```

with authoritative nominal target `x=11` and uncertainty radius `u=2` leaves `x=10`, because 11 lies in `[8,12]`.

The same object with authoritative target `x=20` permits the candidate because 20 lies outside `[8,12]`; the remaining existing causal gates still decide whether it is ultimately committed.

## Deterministic clock domains

`clock_freshness` binds a candidate path/prefix to an explicit timestamp and evaluation time.

The engine **never reads wall-clock time** for this decision. If a clock rule lacks `evaluation_time`, it yields:

`CLOCK_EVALUATION_TIME_REQUIRED`.

The firewall also distinguishes:

- `CLOCK_WITHIN_ADMISSIBLE_WINDOW`;
- `STALE_OBSERVATION_GATE`;
- `FUTURE_SKEW_GATE`;
- unresolved timestamps;
- invalid clock rules.

An optional rule may permit a stale value only when the candidate carries a valid scoped-authority proof; this is explicit rather than inferred.

## Regime firewall

`regime_guard` prevents a candidate learned or certified in one declared regime from mutating a different regime. It can require:

- a concrete `regime_path`;
- an allowed regime domain;
- a candidate metadata binding such as `regime_value`.

Cross-regime transfer yields:

`CROSS_REGIME_CANDIDATE_GATE`.

A rule may also refuse unbound candidates with `CANDIDATE_NOT_REGIME_BOUND` rather than assuming that a global invariant applies to every mode.

## Uncertainty-aware hysteresis

`hysteresis` binds:

- `state_path`;
- `metric_path`;
- `on_value` / `off_value`;
- `enter_above`;
- `exit_below`;
- optional metric uncertainty radius.

For OFF -> ON, the **lower edge** of the admissible metric interval must cross the enter threshold. For ON -> OFF, the **upper edge** must cross the exit threshold. Therefore a noisy point measurement inside the hysteresis band cannot cause flip-flop repair.

Example:

`state=OFF, metric=10.5 +/- 1, enter=10`

has lower edge 9.5 and is gated. With `metric=11.5 +/- 1`, the lower edge is 10.5 and the ON transition survives the envelope.

## Repeated structures

Rules may use `path_pattern` with one-segment `*` bindings, for example:

```text
/rows/*/x
/rows/*/uncertainty
```

The same index binding is substituted into auxiliary paths. This gives repeated arrays per-record robust envelopes without conflating one record's sidecar uncertainty with another's.

## Mutation semantics

The robust layer is a firewall, not a score.

If every candidate for one issue/analyzer/path is rejected by the declared envelope, the issue remains visible but becomes non-repairable for that snapshot. No confidence tiebreak is substituted.

Candidate decisions carry deterministic hashes. Firewall certificates commit:

- normalized rules and rule hashes;
- candidate identities and new-value digests;
- every per-rule decision and gate reason;
- candidate counts before/after the firewall;
- total gated count;
- certificate SHA-256.

The independent verifier checks the outer certificate, every rule hash and every decision hash.

## Single / bundle / streaming

Single JSON exposes the complete robust-envelope cycle history and final firewall certificate.

Bundle mode evaluates document-scoped rules independently. A robust rule scoped to `a.json` does not silently constrain `b.json`.

Streaming record bridges transport the same PASS031 semantics record by record. Robust certificate samples and aggregate gate reasons are exported with bounded memory. Streaming clock behavior is therefore identical in meaning to single-document behavior while preserving the existing record-count-independent memory contract.

## PASS028 proof-graph integration

PASS031 envelopes are committed as `ROBUST_ENVELOPE` / `ROBUST_ENVELOPE_FINAL` nodes in the canonical proof graph.

Thus:

`same repaired JSON + different uncertainty/clock/regime/hysteresis decision`

is no longer the same proof. Full cold proof replay must reproduce the same robust-envelope graph commitment.

## Validation

Current unit/integration suite, executed in bounded groups: **325/325 PASS**:

- segment 1: 77/77;
- segment 2: 70/70;
- segment 3: 92/92;
- segment 4: 86/86.

PASS031 dedicated tests: **8/8 PASS**.

PASS031 dedicated stress: **600/600 PASS**:

- uncertainty inside-envelope abstention: 100;
- uncertainty separated candidate: 100;
- deterministic clock window: 100;
- regime firewall: 100;
- robust hysteresis transition: 100;
- wildcard envelope + certificate tamper rejection: 100.

PASS031 deterministic benchmark: **600/600**, **0 false mutations**.

Historical certified stress ledger through PASS030: **16,225/16,225**. Adding the fresh PASS031 campaign yields **16,825/16,825** cumulative certified stress decisions. Older ledger entries are inherited release evidence and are not represented as freshly re-executed under PASS031 semantics; an attempted monolithic historical stress rerun exceeded the execution window.

Tests + cumulative certified stress ledger: **17,150 PASS**.

## Artifact validation

Reproducible builds:

- wheel produced twice byte-identically: PASS;
- source archive produced twice byte-identically: PASS.

Fresh isolated wheel:

- version 0.31.0: PASS;
- `pip check`: PASS;
- external runtime dependencies: 0;
- uncertainty gate: PASS;
- robust hysteresis repair: PASS;
- terminal cold replay: 0 edits;
- proof-graph replay: `PROOF_GRAPH_REPLAY_EXACT`;
- final independent certification: `CERTIFIED`.

Extracted final source:

- **325/325 tests PASS** (77 + 70 + 92 + 86);
- PASS031 stress: **600/600 PASS**;
- PASS031 benchmark reproduces byte-identically.

## Distribution hashes

Package-code SHA-256:

`56e1322522f08bd344e936e90b6f0e6bd89a56dab123180658ccb41692efdfc0`

Wheel SHA-256:

`ca6db62fc3db15f9ca3389748b5880c986f2fe666d0a7ca480e373fd538b9ba3`

Source SHA-256:

`7d3e3d0ef024bf2002e702fdd031959abd014a13b814bad96ab28af1f719e009`

PASS031 benchmark SHA-256:

`98b66857dc60e31210206a8b1296c5680f16a5e9a86301025029ae91f7cc8998`

Independent certifier code SHA-256:

`3e8fcf93e512a0b09c1a0157f3cb6eb764985fa290fc83abecb3963fee53d49c`

Exact predecessor PASS030 cumulative SHA-256:

`826aeff0936caafae83356d9681cd71cb9a9d04d496ffe346d51576a93706ef8`

## Remaining fourth-series work

Substantive passes remaining: **1**.

Next: **PASS032 — canonical rectification packet + fourth-series reconciliation/closure**. It will make the complete repair trajectory one stable machine-consumable packet and reconcile all fourth-series layers under one final closure contract.
